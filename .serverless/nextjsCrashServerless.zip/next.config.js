// build directory 변경하기
module.exports = {
  distDir: '../../tmp/.next'
}